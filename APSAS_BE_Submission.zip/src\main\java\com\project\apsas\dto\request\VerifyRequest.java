package com.project.apsas.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class VerifyRequest {
    @NotBlank @Email
    private String email;

    @NotBlank
    private String code; // 6 digits
}
